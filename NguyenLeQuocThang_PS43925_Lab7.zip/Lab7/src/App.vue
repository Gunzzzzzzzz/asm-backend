<script setup>
import bai4 from './components/Bai4.vue'
</script>

<template>
  <div class="container">
   <bai4/>
  </div>
  
</template>

<style scoped>

</style>
