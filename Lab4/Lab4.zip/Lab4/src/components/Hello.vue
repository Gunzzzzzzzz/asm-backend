<template> 
    <h1>Chào mừng đến với VueJS</h1> 
</template> 
 <style>     h1{color: red;} 
</style> 
