<script setup>
// Import component của bài 4
import Bai4 from './components/Bai4.vue'; 
</script>

<template>
  <Bai4 />
</template>

<style scoped>
/* CSS cho App.vue */
</style>