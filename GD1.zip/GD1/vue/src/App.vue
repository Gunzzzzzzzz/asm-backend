<template>
  <div style="background: linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%); min-height: 100vh;">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg  bg-gradient shadow-sm" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);">
      <div class="container">
        <a class="navbar-brand fw-bold" href="#" @click.prevent="view='home'" style="font-size: 1.5rem;">
          <i class="fas fa-shopping-bag me-2"></i>ShopPro
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link " href="#" @click.prevent="view='home'"><i class="fas fa-home me-1"></i>Trang chủ</a></li>
            <li class="nav-item"><a class="nav-link " href="#" @click.prevent="view='posts'"><i class="fas fa-newspaper me-1"></i>Bài viết</a></li>
            <li class="nav-item"><a class="nav-link " href="#" @click.prevent="view='profile'"><i class="fas fa-user-circle me-1"></i>Hồ sơ</a></li>
          </ul>
          <ul class="navbar-nav">
            <li v-if="!currentUser" class="nav-item"><a class="nav-link " href="#" @click.prevent="view='login'"><i class="fas fa-sign-in-alt me-1"></i>Đăng nhập</a></li>
            <li v-if="!currentUser" class="nav-item"><a class="nav-link " href="#" @click.prevent="view='register'"><i class="fas fa-user-plus me-1"></i>Đăng ký</a></li>
            <li v-if="currentUser" class="nav-item dropdown">
              <a class="nav-link  dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"><i class="fas fa-user me-1"></i>{{ currentUser.name }}</a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#" @click.prevent="view='profile'"><i class="fas fa-cog me-2"></i>Quản lý hồ sơ</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="#" @click.prevent="logout"><i class="fas fa-sign-out-alt me-2"></i>Đăng xuất</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Banner -->
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 60px 20px; text-align: center; position: relative; overflow: hidden;">
      <div style="position: absolute; top: -50px; left: -50px; width: 200px; height: 200px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
      <div style="position: absolute; bottom: -30px; right: -30px; width: 150px; height: 150px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
      <div style="position: relative; z-index: 1;">
          <h3 class="fw-bold mb-2" style="font-size: 3rem;"><i class="fas fa-pen-fancy me-3"></i>BlogPro</h3>
        <p style="font-size: 1.2rem; opacity: 0.95;">Chia sẻ kiến thức và trải nghiệm — Bài viết, bình luận, hồ sơ</p>
      </div>
    </div>

    <div class="container py-4">
      <!-- Home (intro + featured posts) -->
      <div v-if="view==='home'">
        <div class="row mb-4">
          <div class="col-12 col-lg-8">
            <div class="card border-0 shadow-sm mb-3">
              <div class="card-body">
                <h2 class="fw-bold">Chào mừng đến với BlogPro</h2>
                <p class="text-muted">Nơi chia sẻ kiến thức, câu chuyện và trải nghiệm. Đăng bài, thảo luận và kết nối với cộng đồng.</p>
                <div class="mt-3">
                  <button v-if="currentUser" class="btn" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;" @click="view='create'"><i class="fas fa-pen me-2"></i>Viết bài mới</button>
                  <button class="btn btn-outline-secondary ms-2" @click="view='posts'">Xem tất cả bài viết</button>
                </div>
              </div>
            </div>
            <h5 class="mb-3">Bài viết nổi bật</h5>
            <div class="row g-3">
              <div v-for="p in featuredPosts" :key="p.id" class="col-12">
                <div class="card border-0 shadow-sm p-3">
                  <div class="d-flex align-items-start">
                    <div class="me-3" style="width:56px; height:56px; border-radius:50%; background:#f0f2f5; display:flex; align-items:center; justify-content:center; font-weight:700; color:#667eea;">{{ initials(p.authorId) }}</div>
                    <div style="flex:1">
                      <div class="d-flex justify-content-between">
                        <strong>{{ p.title }}</strong>
                        <small class="text-muted">{{ formatDate(p.createdAt) }}</small>
                      </div>
                      <p class="mb-1 text-muted">{{ p.description }}</p>
                      <div class="d-flex gap-2">
                        <button class="btn btn-sm btn-primary" @click="openDetail(p.id)"><i class="fas fa-eye me-1"></i>Xem</button>
                        <button class="btn btn-sm btn-outline-primary" @click="likePost(p.id)"><i class="fas fa-heart me-1"></i>{{ p.likes || 0 }}</button>
                        <small class="text-muted align-self-center">· {{ p.comments.length }} bình luận</small>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-4">
            <div class="card border-0 shadow-sm p-3 mb-3">
              <h6 class="mb-2">Thống kê</h6>
              <p class="mb-1"><strong>{{ products.length }}</strong> bài viết</p>
              <p class="mb-1"><strong>{{ data.users.length }}</strong> người dùng</p>
              <p class="mb-0"><strong>{{ totalComments }}</strong> bình luận</p>
            </div>
            <div class="card border-0 shadow-sm p-3">
              <h6 class="mb-2">Gợi ý chủ đề</h6>
              <div class="d-flex flex-column gap-2">
                <span class="badge bg-light text-dark">Sức khỏe</span>
                <span class="badge bg-light text-dark">Thể dục</span>
                <span class="badge bg-light text-dark">Dinh dưỡng</span>
                <span class="badge bg-light text-dark">Kinh nghiệm</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Posts list -->
      <div v-if="view==='posts'">
        <!-- Stats Section -->
        <div class="row g-3 mb-4">
          <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
              <div class="card-body text-center">
                <h6 class="mb-2"><i class="fas fa-newspaper me-2"></i>Tổng bài viết</h6>
                <h3 class="mb-0 fw-bold">{{ products.length }}</h3>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
              <div class="card-body text-center">
                <h6 class="mb-2"><i class="fas fa-users me-2"></i>Người dùng</h6>
                <h3 class="mb-0 fw-bold">{{ data.users.length }}</h3>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-4">
            <div class="card border-0 shadow-sm" style="background: linear-gradient(135deg, #1dd1a1 0%, #10ac84 100%); color: white;">
              <div class="card-body text-center">
                <h6 class="mb-2"><i class="fas fa-comments me-2"></i>Bình luận</h6>
                <h3 class="mb-0 fw-bold">{{ totalComments }}</h3>
              </div>
            </div>
          </div>
        </div>

        <!-- Product Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h3 class="mb-1 fw-bold" style="color:#333;"><i class="fas fa-newspaper me-2" style="color:#667eea;"></i>Danh sách bài viết</h3>
            <p class="text-muted mb-0">Tổng: {{ products.length }} bài viết</p>
          </div>
          <div>
            <button v-if="currentUser" class="btn" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;" @click="view='create'"><i class="fas fa-pen me-2"></i>Viết bài</button>
          </div>
        </div>

        <div v-if="products.length===0" class="alert alert-info text-center">
          <i class="fas fa-info-circle me-2"></i>Chưa có sản phẩm nào
        </div>

        <div class="row g-4">
          <div v-for="p in products" :key="p.id" class="col-12 col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100 transition" style="transform: translateY(0); transition: all 0.3s ease;" @mouseenter="$event.target.closest('.card').style.transform='translateY(-5px)'; $event.target.closest('.card').style.boxShadow='0 10px 25px rgba(0,0,0,0.15)';" @mouseleave="$event.target.closest('.card').style.transform='translateY(0)'; $event.target.closest('.card').style.boxShadow='0 0.125rem 0.25rem rgba(0,0,0,0.075)';">
              <div class="card-header bg-light border-0 d-flex justify-content-between align-items-center" style="padding: 15px;">
                <span class="badge" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); font-size: 0.75rem;">ID: {{ p.id }}</span>
                <span class="badge bg-success">{{ p.comments.length }} bình luận</span>
              </div>
              <div class="card-body">
                <div v-if="p.image" class="mb-2">
                  <img :src="p.image" alt="image" style="width:100%; max-height:180px; object-fit:cover; border-radius:6px;" />
                </div>
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <h5 class="card-title mb-0 fw-bold" style="color:#333;">{{ p.title }}</h5>
                  <span class="badge" style="background: linear-gradient(90deg, #f093fb 0%, #f5576c 100%); font-size: 0.9rem;">Lượt xem: {{ p.price.toLocaleString() }}</span>
                </div>
                <p class="card-text text-muted" style="font-size: 0.9rem; line-height: 1.4;">{{ p.description }}</p>
                <div class="mb-2 pt-2 border-top">
                  <small class="text-muted"><i class="fas fa-user-circle me-1" style="color:#667eea;"></i><strong>{{ authorName(p.authorId) }}</strong></small>
                </div>
                <div class="d-grid gap-2">
                  <button class="btn btn-sm" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;" @click="openDetail(p.id)"><i class="fas fa-eye me-1"></i>Xem chi tiết</button>
                  <button v-if="currentUser && currentUser.id===p.authorId" class="btn btn-sm btn-outline-danger" @click="removeProduct(p.id)"><i class="fas fa-trash me-1"></i>Xóa</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Create product -->
      <div v-if="view==='create'">
        <div class="card border-0 shadow mx-auto" style="max-width:760px;">
          <div class="card-header" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;">
            <h5 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Tạo bài viết mới</h5>
          </div>
          <div class="card-body">
            <form @submit.prevent="createProduct">
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Tiêu đề bài viết <span class="text-danger">*</span></label>
                <input v-model="form.title" class="form-control form-control-lg border-0 bg-light" placeholder="Nhập tiêu đề bài viết" required>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Mô tả <span class="text-danger">*</span></label>
                <textarea v-model="form.description" class="form-control border-0 bg-light" rows="4" placeholder="Nhập mô tả chi tiết" required></textarea>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Ảnh đính kèm</label>
                <input type="file" accept="image/*" class="form-control form-control-sm border-0 bg-light" @change="handleImageUpload">
                <div v-if="form.image" class="mt-2">
                  <img :src="form.image" alt="preview" style="max-width:100%; max-height:240px; object-fit:cover; border-radius:6px;" />
                  <div class="mt-2">
                    <button class="btn btn-sm btn-outline-danger" @click.prevent="removeImage"><i class="fas fa-times me-1"></i>Xóa ảnh</button>
                  </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Lượt xem <span class="text-muted">(số, có thể để 0)</span></label>
                <input v-model.number="form.price" type="number" class="form-control form-control-lg border-0 bg-light" placeholder="Nhập số lượt xem" required>
              </div>
              <div class="d-flex gap-2">
                <button class="btn btn-lg" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none; flex:1;"><i class="fas fa-paper-plane me-2"></i>Đăng bài</button>
                <button class="btn btn-lg btn-outline-secondary" @click.prevent="view='home'"><i class="fas fa-times me-2"></i>Hủy</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Login -->
      <div v-if="view==='login'" class="mx-auto" style="max-width:480px">
        <div class="card border-0 shadow">
          <div class="card-header" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;">
            <h5 class="mb-0"><i class="fas fa-lock me-2"></i>Đăng nhập tài khoản</h5>
          </div>
          <div class="card-body">
            <form @submit.prevent="login">
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Email</label>
                <input v-model="auth.email" type="email" class="form-control form-control-lg border-0 bg-light" placeholder="admin@example.com" required>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Mật khẩu</label>
                <input v-model="auth.password" type="password" class="form-control form-control-lg border-0 bg-light" placeholder="Nhập mật khẩu" required>
              </div>
              <button class="btn btn-lg w-100" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;"><i class="fas fa-sign-in-alt me-2"></i>Đăng nhập</button>
            </form>
            <div v-if="authMsg" class="mt-3 alert alert-danger mb-0"><i class="fas fa-exclamation-circle me-2"></i>{{ authMsg }}</div>
          </div>
        </div>
      </div>

      <!-- Register -->
      <div v-if="view==='register'" class="mx-auto" style="max-width:480px">
        <div class="card border-0 shadow">
          <div class="card-header" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;">
            <h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Tạo tài khoản mới</h5>
          </div>
          <div class="card-body">
            <form @submit.prevent="register">
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Họ tên</label>
                <input v-model="reg.name" class="form-control form-control-lg border-0 bg-light" placeholder="Nhập họ tên" required>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Email</label>
                <input v-model="reg.email" type="email" class="form-control form-control-lg border-0 bg-light" placeholder="Nhập email" required>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Mật khẩu</label>
                <input v-model="reg.password" type="password" class="form-control form-control-lg border-0 bg-light" placeholder="Nhập mật khẩu" required>
              </div>
              <button class="btn btn-lg w-100" style="background: linear-gradient(90deg, #1dd1a1 0%, #10ac84 100%); color:white; border:none;"><i class="fas fa-check me-2"></i>Tạo tài khoản</button>
            </form>
            <div v-if="regMsg" class="mt-3 alert alert-info mb-0"><i class="fas fa-info-circle me-2"></i>{{ regMsg }}</div>
          </div>
        </div>
      </div>

      <!-- Profile -->
      <div v-if="view==='profile'" class="mx-auto" style="max-width:640px">
        <div class="card border-0 shadow">
          <div class="card-header" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;">
            <h5 class="mb-0"><i class="fas fa-user-circle me-2"></i>Hồ sơ cá nhân</h5>
          </div>
          <div class="card-body">
            <div v-if="currentUser">
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Tên</label>
                <input v-model="profile.name" class="form-control form-control-lg border-0 bg-light">
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Email</label>
                <input v-model="profile.email" class="form-control form-control-lg border-0 bg-light" disabled>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold" style="color:#333;">Ghi chú</label>
                <textarea v-model="profile.bio" class="form-control border-0 bg-light" rows="3" placeholder="Nhập ghi chú về bạn"></textarea>
              </div>
              <button class="btn btn-lg w-100" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;" @click="saveProfile"><i class="fas fa-save me-2"></i>Lưu thay đổi</button>
            </div>
            <div v-else>
              <div class="alert alert-warning mb-0"><i class="fas fa-warning me-2"></i>Vui lòng đăng nhập để quản lý hồ sơ.</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Product Detail Modal -->
    <div class="modal fade" id="detailModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow-lg">
          <div class="modal-header" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;">
            <h5 class="modal-title fw-bold"><i class="fas fa-cube me-2"></i>{{ detail?.title }}</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
                  <div class="modal-body">
                  <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                      <h5 class="mb-1 fw-bold">{{ detail?.title }}</h5>
                      <small class="text-muted">{{ authorName(detail?.authorId) }} · {{ formatDate(detail?.createdAt) }}</small>
                    </div>
                    <div class="text-end">
                      <div>
                        <button class="btn btn-sm btn-outline-primary me-2" @click="likePost(detail.id)"><i class="fas fa-heart me-1"></i>{{ detail?.likes || 0 }}</button>
                        <span class="badge" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); font-size:0.9rem;">{{ detail?.comments?.length || 0 }} bình luận</span>
                      </div>
                    </div>
                  </div>
                  <div class="card bg-light border-0 mb-3">
                    <div class="card-body">
                      <div v-if="detail?.image" class="mb-3">
                        <img :src="detail.image" alt="detail image" style="width:100%; max-height:320px; object-fit:cover; border-radius:6px;" />
                      </div>
                      <p class="mb-0">{{ detail?.description }}</p>
                    </div>
                  </div>
            <hr>
            <h6 class="fw-bold mb-3"><i class="fas fa-comments me-2" style="color:#667eea;"></i>Bình luận</h6>
            <div class="mb-3" style="max-height:300px; overflow-y:auto;">
              <ul class="list-unstyled">
                <li v-for="c in detail?.comments" :key="c.id" class="mb-3 pb-3 border-bottom">
                  <div class="d-flex justify-content-between">
                    <strong class="text-dark">{{ c.author }}</strong>
                    <small class="text-muted">{{ c.id }}</small>
                  </div>
                  <p class="mb-0 mt-1 text-muted">{{ c.text }}</p>
                </li>
              </ul>
            </div>
            <div class="mt-3">
              <label class="form-label fw-bold" style="color:#333;">Viết bình luận</label>
              <textarea v-model="commentText" class="form-control border-0 bg-light" rows="2" placeholder="Chia sẻ ý kiến của bạn..."></textarea>
              <div class="mt-2 text-end">
                <button class="btn" style="background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); color:white; border:none;" @click="addComment"><i class="fas fa-paper-plane me-1"></i>Gửi bình luận</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, computed, onMounted } from 'vue'

const stateKey = 'gd1-shop-state-v1'
const raw = localStorage.getItem(stateKey)
const data = reactive(raw ? JSON.parse(raw) : {
  users: [{ id:1, name:'Admin', email:'admin@example.com', password:'admin', bio:'Quản trị viên cửa hàng' }],
  currentUserId: null,
  products: [
    { id:1, authorId:1, title:'Gối tập Pilates', description:'Gối cao su êm, chất lượng cao, giúp tập luyện hiệu quả, an toàn cho xương khớp', price:120000, comments:[{id:1,author:'Khách',text:'Sản phẩm tốt'}], likes:12, createdAt: new Date().toISOString() },
    { id:2, authorId:1, title:'Tạ tay 5kg', description:'Tạ tay chất lượng cao, được sơn bên ngoài, rất bền và an toàn khi tập luyện', price:250000, comments:[{id:2,author:'Khách',text:'Rất hài lòng với chất lượng'}], likes:8, createdAt: new Date(Date.now()-1000*60*60*24).toISOString() },
    { id:3, authorId:1, title:'Thảm yoga cao cấp', description:'Thảm yoga chống trơn, dày 6mm, phù hợp cho mọi loại tập luyện', price:350000, comments:[], likes:5, createdAt: new Date(Date.now()-1000*60*60*48).toISOString() },
    { id:4, authorId:1, title:'Dây jump rope', description:'Dây nhảy tốc độ cao, cắp tay an toàn, phù hợp cho cardio', price:80000, comments:[{id:3,author:'Khách',text:'Tốt lắm'}], likes:3, createdAt: new Date(Date.now()-1000*60*60*72).toISOString() },
    { id:5, authorId:1, title:'Quả tạ kettlebell 8kg', description:'Kettlebell chất lượng cao, phù hợp tập luyện trên toàn thân', price:180000, comments:[], likes:2, createdAt: new Date(Date.now()-1000*60*60*96).toISOString() },
    { id:6, authorId:1, title:'Dây kéo đàn hồi', description:'Bộ 5 dây kéo đàn hồi, mỗi dây có độ kháng khác nhau', price:150000, comments:[], likes:1, createdAt: new Date(Date.now()-1000*60*60*120).toISOString() },
    { id:7, authorId:1, title:'Giầy tập gym', description:'Giầy tập luyện chuyên nghiệp, đế bền, thoáng khí', price:450000, comments:[], likes:6, createdAt: new Date(Date.now()-1000*60*60*140).toISOString() },
    { id:8, authorId:1, title:'Bình nước thể thao', description:'Bình nước 1 lít, chất liệu nhựa an toàn, không BPA', price:120000, comments:[], likes:0, createdAt: new Date(Date.now()-1000*60*60*160).toISOString() }
  ],
  nextIds: { user:2, product:9, comment:4 }
})

function save(){ localStorage.setItem(stateKey, JSON.stringify(data)) }

const view = ref('home')
const form = reactive({ title:'', description:'', price:0, image: null })
const auth = reactive({ email:'', password:'' })
const reg = reactive({ name:'', email:'', password:'' })
const regMsg = ref('')
const authMsg = ref('')
const profile = reactive({ name:'', email:'', bio:'' })
const commentText = ref('')
const detail = ref(null)

const currentUser = computed(()=> data.users.find(u=>u.id===data.currentUserId) || null)
const products = data.products
const totalComments = computed(()=> data.products.reduce((sum, p)=> sum + p.comments.length, 0))

const sortedPosts = computed(()=> [...data.products].sort((a,b)=> new Date(b.createdAt || 0) - new Date(a.createdAt || 0)))
const featuredPosts = computed(()=> [...data.products].sort((a,b)=> (b.likes||0) - (a.likes||0)).slice(0,3))

function formatDate(iso){ if(!iso) return ''; try{ const d=new Date(iso); return d.toLocaleString() }catch(e){return iso} }
function initials(authorId){ const u = data.users.find(x=>x.id===authorId); if(!u) return 'U'; return (u.name||'U').split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase() }
function likePost(id){ const p = data.products.find(x=>x.id===id); if(!p) return; p.likes = (p.likes||0)+1; save() }

function register(){
  if (data.users.some(u=>u.email===reg.email)) { regMsg.value = 'Email đã tồn tại'; return }
  const id = data.nextIds.user++
  data.users.push({ id, name: reg.name, email: reg.email, password: reg.password, bio:'' })
  save(); regMsg.value = 'Đăng ký thành công'; reg.name=''; reg.email=''; reg.password='';
  setTimeout(()=> { view.value='login'; regMsg.value=''}, 800)
}

function login(){
  const u = data.users.find(x=>x.email===auth.email && x.password===auth.password)
  if(!u){ authMsg.value='Thông tin không đúng'; return }
  data.currentUserId = u.id; save(); authMsg.value=''; auth.email=''; auth.password=''; view.value='home'
  profile.name = u.name; profile.email = u.email; profile.bio = u.bio || ''
}

function logout(){ data.currentUserId = null; save(); view.value='home' }

function createProduct(){
  if(!currentUser.value){ alert('Cần đăng nhập'); return }
  const id = data.nextIds.product++
  data.products.unshift({ id, authorId: currentUser.value.id, title: form.title, description: form.description, price: form.price, image: form.image || null, comments: [], likes:0, createdAt: new Date().toISOString() })
  save(); form.title=''; form.description=''; form.price=0; view.value='home'
}

function removeProduct(id){ const idx = data.products.findIndex(p=>p.id===id); if(idx>=0) data.products.splice(idx,1); save() }

function openDetail(id){ detail.value = data.products.find(p=>p.id===id); const m = new bootstrap.Modal(document.getElementById('detailModal')); m.show() }

function addComment(){ if(!detail.value || !commentText.value) return; const id = data.nextIds.comment++; const author = currentUser.value?currentUser.value.name:'Khách'; detail.value.comments.push({ id, author, text: commentText.value }); commentText.value=''; save() }

function authorName(id){ const u = data.users.find(x=>x.id===id); return u?u.name:'Khách' }

function saveProfile(){ if(!currentUser.value){ alert('Vui lòng đăng nhập'); return } currentUser.value.name = profile.name; currentUser.value.bio = profile.bio; save(); alert('Đã lưu') }

function handleImageUpload(e){
  const file = e.target.files && e.target.files[0]
  if(!file) return
  const reader = new FileReader()
  reader.onload = () => { form.image = reader.result }
  reader.readAsDataURL(file)
}

function removeImage(){ form.image = null }

onMounted(()=>{
  if(currentUser.value){ profile.name = currentUser.value.name; profile.email = currentUser.value.email; profile.bio = currentUser.value.bio||'' }
})
</script>

<style scoped>
.transition {
  transition: all 0.3s ease;
}
</style>
