# GD1 Vue demo

Run (PowerShell):

```powershell
cd GD1/vue
npm install
npm run dev
```

This is a minimal Vite + Vue 3 project using Bootstrap via CDN.
